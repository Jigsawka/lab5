// widget.cpp
#include "widget.h"
#include "ui_widget.h"

#include <QVector>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QIntValidator>
#include <QSettings>
#include <QDateTime>
#include <QMessageBox>
#include <QDebug>
#include <QLocale>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
    , ttl(new QSerialPort(this))
    , plotTimer(new QTimer(this))
{
    ui->setupUi(this);

    // Fuente UI
    QFont font;
    font.setPointSize(8);
    font.setBold(true);
    font.setItalic(true);
    font.setFamily("Comic Sans MS");

    ui->label->setVisible(false);
    ui->label3->setVisible(false);

    ui->label->setFont(font);
    ui->label2->setFont(font);
    ui->label_2->setFont(font);
    ui->label3->setFont(font);

    ui->label2->setText("Ingrese la velocidad en mm/s para el motor");
    ui->label2->adjustSize();

    ui->label_2->setText("Seleccione el puerto COM");
    ui->label_2->adjustSize();

    ui->pushButton->setText("ARRANCAR");
    ui->pushButton_2->setText("FRENAR");
    ui->pushButton_3->setText("Abrir");
    ui->pushButton_4->setText("Refresh");
    ui->pushButton_5->setText("Graficar");
    ui->pushButton_5->adjustSize();
    ui->pushButton_6->setText("Sorpresa");
    ui->pushButton_7->setText("Limpiar");
    ui->pushButton_7->adjustSize();

    // Validador para el lineEdit (0..65535)
    ui->lineEdit->setValidator(new QIntValidator(0, 65535, this));

    // Cargar puertos disponibles
    ui->comboBox->clear();
    for (const QSerialPortInfo &info : QSerialPortInfo::availablePorts()) {
        ui->comboBox->addItem(info.portName());
    }

    // Conexiones del puerto (error y bytesWritten)
    connect(ttl, &QSerialPort::bytesWritten, this, &Widget::onBytesWritten);
    connect(ttl, &QSerialPort::errorOccurred, this, &Widget::onSerialError);

    // Inicializar variables de plot
    setupPlot();

    // Timer para actualizar gráficas
    plotTimer->setInterval(100); // ms
    connect(plotTimer, &QTimer::timeout, this, &Widget::updatePlotTick);

    // Restaurar último puerto seleccionado (opcional)
    QSettings s;
    QString lastPort = s.value("serial/port").toString();
    if (!lastPort.isEmpty()) {
        int idx = ui->comboBox->findText(lastPort);
        if (idx >= 0) ui->comboBox->setCurrentIndex(idx);
    }

    serialData.clear();
    txQueue.clear();

    // Inicializaciones de objetivos
    targetVel = 0;
    targetRPM = 0;
    targetDir = 0;
    targetDs1 = targetDs2 = targetDs3 = targetDs4 = 0.0;
    plotting = false;
}

Widget::~Widget()
{
    // Asegurar cierre y desconexión de señales
    if (ttl) {
        if (ttl->isOpen()) ttl->close();
        disconnect(ttl, &QSerialPort::readyRead, this, &Widget::readSerial);
        disconnect(ttl, &QSerialPort::bytesWritten, this, &Widget::onBytesWritten);
        disconnect(ttl, &QSerialPort::errorOccurred, this, &Widget::onSerialError);
    }
    delete ui;
}

void Widget::enviarVEL(const QString &vel)
{
    QByteArray enviar = vel.toUtf8();
    enviar.append('\n');

    if (!ttl || !ttl->isOpen()) return;

    // Si la cola está vacía, intentar escribir inmediatamente
    if (txQueue.isEmpty()) {
        qint64 written = ttl->write(enviar);
        if (written < 0) {
            qWarning() << "Error escribiendo en el puerto:" << ttl->errorString();
            return;
        }
        if (written < enviar.size()) {
            txQueue.append(enviar.mid(written));
        }
    } else {
        // Cola no vacía: acumular
        txQueue.append(enviar);
    }
}

void Widget::onBytesWritten(qint64 bytes)
{
    Q_UNUSED(bytes);
    if (!ttl || !ttl->isOpen()) return;
    if (txQueue.isEmpty()) return;

    qint64 wrote = ttl->write(txQueue);
    if (wrote > 0) {
        txQueue.remove(0, wrote);
    } else if (wrote < 0) {
        qWarning() << "Error en onBytesWritten:" << ttl->errorString();
    }
}

void Widget::onSerialError(QSerialPort::SerialPortError err)
{
    if (err == QSerialPort::NoError) return;
    QMessageBox::warning(this, tr("Error puerto serie"), ttl->errorString());
}

void Widget::setupPlot()
{
    const int N = 101;
    x.resize(N);
    for (int i = 0; i < N; ++i)
        x[i] = i;

    // === VELOCIDADES (mm/s) en distintos voltajes ===
    QVector<double> voltajes = {5.5};
    yVoltajes.clear();

    ui->customPlot->clearGraphs();

    for (int k = 0; k < voltajes.size(); ++k) {
        QVector<double> y(N, 0.0);
        yVoltajes.append(y);

        ui->customPlot->addGraph(ui->customPlot->xAxis, ui->customPlot->yAxis);
        ui->customPlot->graph(k)->setData(x, yVoltajes[k]);
        ui->customPlot->graph(k)->setName(QString("mm/s @ %1 V").arg(voltajes[k]));

        QColor c = QColor::fromHsv((k*80)%360, 200, 240);
        ui->customPlot->graph(k)->setPen(QPen(c, 2));
    }

    // === RPM en eje derecho (yAxis2) ===
    rpmData = QVector<double>(N, 0.0);
    ui->customPlot->addGraph(ui->customPlot->xAxis, ui->customPlot->yAxis2);
    int rpmIndex = ui->customPlot->graphCount() - 1;
    ui->customPlot->graph(rpmIndex)->setData(x, rpmData);
    ui->customPlot->graph(rpmIndex)->setName("RPM");
    ui->customPlot->graph(rpmIndex)->setPen(QPen(Qt::yellow, 2));

    // Configurar ejes
    ui->customPlot->xAxis->setLabel("Tiempo");
    ui->customPlot->yAxis->setLabel("Velocidad (mm/s)");
    ui->customPlot->yAxis2->setLabel("RPM");

    ui->customPlot->xAxis->setRange(0, N-1);
    ui->customPlot->yAxis->setRange(0, 400);
    ui->customPlot->yAxis2->setRange(0, 300);
    ui->customPlot->yAxis2->setVisible(true);

    ui->customPlot->legend->setVisible(true);

    // Evitar rangos degenerados (causa común del warning de QLineF)
    auto fixRangeIfDegenerate = [this](QCPAxis *axis) {
        double lo = axis->range().lower;
        double hi = axis->range().upper;
        if (qFuzzyCompare(lo + 1.0, hi + 1.0)) { // compara con tolerancia
            axis->setRange(lo - 1.0, hi + 1.0);
        }
    };

    fixRangeIfDegenerate(ui->customPlot->xAxis);
    fixRangeIfDegenerate(ui->customPlot->yAxis);
    fixRangeIfDegenerate(ui->customPlot->yAxis2);

    ui->customPlot->replot();
}

void Widget::updatePlotTick()
{
    // Si no hay curvas configuradas, salir
    if (yVoltajes.isEmpty()) return;

    // Solo usamos la primera serie para representar la velocidad real
    QVector<double> &serie = yVoltajes[0];

    // desplazar ventana: mover todos los valores a la izquierda
    const int len = serie.size();
    if (len <= 1) return;
    for (int i = 0; i < len - 1; ++i)
        serie[i] = serie[i + 1];

    // poner el último valor igual a la velocidad recibida (sin escala)
    serie.last() = targetVel;

    // aplicar la serie al gráfico 0 (suponiendo que la primera gráfica es la de velocidad)
    if (ui->customPlot->graphCount() > 0) {
        ui->customPlot->graph(0)->setData(x, serie);
        ui->customPlot->graph(0)->rescaleValueAxis(true); // opcional: ajusta solo eje Y en base a datos de esta gráfica
    }

    // Actualizar RPM (se mantiene igual que antes)
    if (!rpmData.isEmpty()) {
        for (int i = 0; i < rpmData.size() - 1; ++i)
            rpmData[i] = rpmData[i + 1];
        rpmData.last() = targetRPM;

        // La curva de RPM sigue siendo la última añadida en setupPlot()
        int rpmIndex = ui->customPlot->graphCount() - 1;
        if (rpmIndex > 0) {
            ui->customPlot->graph(rpmIndex)->setData(x, rpmData);
        }
    }

    // Autoscale sencillo del eje Y para asegurar que valores altos se vean bien
    double upper = ui->customPlot->yAxis->range().upper;
    if (targetVel > 0 && targetVel > upper * 0.9) {
        ui->customPlot->yAxis->setRange(0, targetVel * 1.2); // 20% de margen
    }

    // Redibujar
    ui->customPlot->replot();
}

void Widget::readSerial()
{
    QByteArray chunk = ttl->readAll();
    serialData.append(chunk);

    while (true) {
        int nl = serialData.indexOf('\n');
        if (nl < 0) break;

        QByteArray rawLine = serialData.left(nl);
        serialData.remove(0, nl + 1);
        rawLine = rawLine.trimmed();

        if (rawLine.isEmpty()) continue;

        QString line = QString::fromUtf8(rawLine);
        QStringList pairs;

        // Soporte para ambos formatos: multi-línea o separada por ';'
        if (line.contains(';'))
            pairs = line.split(';', QString::SkipEmptyParts);
        else
            pairs = line.split('\n', QString::SkipEmptyParts);

        for (const QString &pair : pairs) {
            int colon = pair.indexOf(':');
            if (colon < 0) continue;

            QString key = pair.left(colon).trimmed();
            QString val = pair.mid(colon + 1).trimmed();

            bool ok = false;
            if (key == "RPM") targetRPM = val.toDouble(&ok);
            else if (key == "DIR" && !val.isEmpty()) targetDir = val.at(0).toLatin1();
            else if (key == "VEL") targetVel = val.toDouble(&ok);
            else if (key == "DS1") targetDs1 = val.toDouble(&ok);
            else if (key == "DS2") targetDs2 = val.toDouble(&ok);
            else if (key == "DS3") targetDs3 = val.toDouble(&ok);
            else if (key == "DS4") targetDs4 = val.toDouble(&ok);
            ui->textEdit->append(val);
        }

    }
}


void Widget::on_pushButton_clicked()
{
    QString texto = ui->lineEdit->text().trimmed();
    if (texto.isEmpty()) {
        ui->label->setVisible(true);
        ui->label->setText(tr("Ingrese la velocidad."));
        ui->label->adjustSize();
        return;
    }

    bool ok = false;
    quint32 v = texto.toUInt(&ok);
    if (!ok || v > 65535u) {
        ui->label->setVisible(true);
        ui->label->setText(tr("Velocidad inválida (0..65535)."));
        ui->label->adjustSize();
        return;
    }

    ui->label->setVisible(true);
    ui->label->setText(tr("Velocidad en mm/s esperada: %1").arg(v));
    ui->label->adjustSize();

    // Enviar como string seguro
    enviarVEL(QString::number(v));
}

void Widget::on_pushButton_2_clicked()
{
    enviarVEL("0");
}

void Widget::on_pushButton_3_clicked()
{
    if (!ttl) return;

    if (!ttl->isOpen()) {
        const QString port = ui->comboBox->currentText().trimmed();
        if (port.isEmpty()) return;

        ttl->setPortName(port);
        ttl->setBaudRate(QSerialPort::Baud115200);
        ttl->setDataBits(QSerialPort::Data8);
        ttl->setParity(QSerialPort::NoParity);
        ttl->setStopBits(QSerialPort::OneStop);
        ttl->setFlowControl(QSerialPort::NoFlowControl);

        if (!ttl->open(QIODevice::ReadWrite)) {
            qWarning() << "No se pudo abrir" << port << ":" << ttl->errorString();
            QMessageBox::warning(this, tr("Error abrir puerto"), ttl->errorString());
            return;
        }
        connect(ttl, &QSerialPort::readyRead, this, &Widget::readSerial, Qt::UniqueConnection);
        ui->pushButton_3->setText("Cerrar");

        // Guardar la selección
        QSettings s;
        s.setValue("serial/port", port);
    } else {
        // cerrar puerto y desconectar señales
        ttl->close();
        disconnect(ttl, &QSerialPort::readyRead, this, &Widget::readSerial);
        ui->pushButton_3->setText("Abrir");
    }
}

void Widget::on_pushButton_4_clicked()
{
    ui->comboBox->clear();
    const auto ports = QSerialPortInfo::availablePorts();
    for (const auto &info : ports)
        ui->comboBox->addItem(info.portName());
}

void Widget::on_pushButton_5_clicked()
{
    plotting = !plotting;
    if (plotting) {
        ui->pushButton_5->setText("STOP");
        plotTimer->start();
    } else {
        plotTimer->stop();
        ui->pushButton_5->setText("Graficar");
    }
}

void Widget::on_pushButton_6_clicked()
{
    QUrl url("https://www.youtube.com/watch?v=fMiq-utP6SY&list=RDSr2D5YwJKCk&index=3");
    QDesktopServices::openUrl(url);
}

void Widget::on_pushButton_7_clicked()
{
    ui->textEdit->clear();
}

void Widget::on_horizontalSlider_actionTriggered(int action)
{
    Q_UNUSED(action);
    int val = ui->horizontalSlider->value();
    enviarVEL(QString::number(val));
}

void Widget::on_pushButton_8_clicked()
{
    // Placeholder - implementar lo que necesites aquí
}

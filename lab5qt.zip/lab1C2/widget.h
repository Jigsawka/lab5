#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QVector>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QTimer>
#include <QByteArray>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void readSerial();
    void enviarVEL(const QString &vel);

    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_4_clicked();
    void on_pushButton_5_clicked();
    void on_pushButton_6_clicked();
    void on_pushButton_7_clicked();
    void on_pushButton_8_clicked();
    void on_horizontalSlider_actionTriggered(int action);

    void setupPlot();
    void updatePlotTick();

    void onBytesWritten(qint64 bytes);
    void onSerialError(QSerialPort::SerialPortError err);

private:
    Ui::Widget *ui;

    // Comunicación serial
    QSerialPort *ttl = nullptr;
    QByteArray serialData;
    QByteArray txQueue;
    QString serialBuffer;
    QString parsed_data;

    // Variables para graficar
    QVector<double> x;                    // eje X común
    QVector<QVector<double>> yVoltajes;   // múltiples curvas Y (velocidad)
    QVector<double> rpmData;              // curva RPM
    QTimer *plotTimer = nullptr;
    bool plotting = false;

    // Variables de datos recibidos
    double targetVel = 0.0;
    double targetRPM = 0.0;
    char targetDir = 0;
    double targetDs1 = 0.0;
    double targetDs2 = 0.0;
    double targetDs3 = 0.0;
    double targetDs4 = 0.0;
};

#endif // WIDGET_H

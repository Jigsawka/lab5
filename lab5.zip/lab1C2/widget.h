#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QVector>
#include <QSerialPort>
#include <QSerialPortInfo>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
private slots:

    void readSerial();
    //void processSerial(QString datos);
    void enviarVEL(QString vel);

    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_4_clicked();
    void on_pushButton_5_clicked();
    void on_pushButton_6_clicked();

    void setupPlot();

    void updatePlotTick();
    //void processFrame(quint8 cmd, quint8 p0, quint8 p1, quint8 p2, quint8 p3);
    void on_pushButton_7_clicked();

    void on_horizontalSlider_actionTriggered(int action);

    void on_pushButton_8_clicked();

private:
    Ui::Widget *ui;

    QByteArray serialData,rxBuf;
    QString serialBuffer;
    QString parsed_data;
    QSerialPort *ttl;

    QVector<double> x;
    QVector<double> y;
    QVector<double> z;
    QVector<double> w;

    QTimer *plotTimer = nullptr;
    bool plotting = false;

    double targetVel,targetRPM,targetDir,targetDs1,targetDs2,targetDs3,targetDs4;

    //QVector<double> x;                   // eje X común
    QVector<QVector<double>> yVoltajes;  // varias curvas Y
    QVector<double> rpmData;             // una curva para RPM


};
#endif // WIDGET_H

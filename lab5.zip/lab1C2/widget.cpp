#include "widget.h"
#include "ui_widget.h"

#include <QVector>
#include <QSerialPort>
#include <QSerialPortInfo>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    QFont font;
    font.setPointSize(8);
    font.setBold(true);
    font.setItalic(true);
    font.setFamily("Comic Sans MS");

    ui->setupUi(this);

    ui->label->setVisible(false);
    ui->label3->setVisible(false);

    ui->label->setFont(font);
    ui->label2->setFont(font);
    ui->label_2->setFont(font);
    ui->label3->setFont(font);

    ui->label2->setText("Ingrese la velocidad en mm/s para el motor");
    ui->label2->adjustSize();

    ui->label_2->setText("Seleccione el puerto COM");
    ui->label_2->adjustSize();

    ui->pushButton->setText("ARRANCAR");
    ui->pushButton_2->setText("FRENAR");
    ui->pushButton_3->setText("Abrir");
    ui->pushButton_4->setText("Refresh");
    ui->pushButton_5->setText("Graficar");
    ui->pushButton_5->adjustSize();
    ui->pushButton_6->setText("Sorpresa");
    ui->pushButton_7->setText("Limpiar");
    ui->pushButton_7->adjustSize();
    ttl = new QSerialPort(this);
    serialBuffer = "";
    parsed_data = "";

    foreach(const QSerialPortInfo &serialPortInfo, QSerialPortInfo::availablePorts()){
        QString pname = serialPortInfo.portName();
        ui->comboBox->addItem(pname);
    }
    setupPlot();
    plotTimer = new QTimer(this);
    plotTimer->setInterval(100); // ms, ajusta
    connect(plotTimer, &QTimer::timeout, this, &Widget::updatePlotTick);

}

Widget::~Widget()
{
    if (ttl->isOpen()){
       ttl->close();
       QObject::disconnect(ttl, SIGNAL(readyRead()), this, SLOT(readSerial()));
   }
    delete ui;
}

void Widget::enviarVEL(QString vel){
    QByteArray enviar = vel.toUtf8();
    enviar.append('\n');
    if (ttl && ttl->isOpen()) {
        ttl->write(enviar);
        ttl->waitForBytesWritten(20);
    }
}

void Widget::setupPlot()
{
    const int N = 101;
    x.resize(N);
    for (int i = 0; i < N; ++i)
        x[i] = i;

    // === VELOCIDADES (mm/s) en distintos voltajes ===
    QVector<double> voltajes = {5.5};
    yVoltajes.clear();

    ui->customPlot->clearGraphs();

    for (int k = 0; k < voltajes.size(); ++k) {
        QVector<double> y(N, 0.0);
        yVoltajes.append(y);

        ui->customPlot->addGraph(ui->customPlot->xAxis, ui->customPlot->yAxis);
        ui->customPlot->graph(k)->setData(x, yVoltajes[k]);
        ui->customPlot->graph(k)->setName(QString("mm/s @ %1 V").arg(voltajes[k]));

        QColor c = QColor::fromHsv((k*80)%360, 200, 240);
        ui->customPlot->graph(k)->setPen(QPen(c, 2));
    }

    // === RPM en eje derecho (yAxis2) ===
    rpmData = QVector<double>(N, 0.0);
    ui->customPlot->addGraph(ui->customPlot->xAxis, ui->customPlot->yAxis2);
    int rpmIndex = ui->customPlot->graphCount() - 1;
    ui->customPlot->graph(rpmIndex)->setData(x, rpmData);
    ui->customPlot->graph(rpmIndex)->setName("RPM");
    ui->customPlot->graph(rpmIndex)->setPen(QPen(Qt::yellow, 2));

    // Configurar ejes
    ui->customPlot->xAxis->setLabel("Tiempo");
    ui->customPlot->yAxis->setLabel("Velocidad (mm/s)");
    ui->customPlot->yAxis2->setLabel("RPM");
    ui->customPlot->xAxis->setRange(0, N-1);
    ui->customPlot->yAxis->setRange(0, 1000);
    ui->customPlot->yAxis2->setRange(0, 300);
    ui->customPlot->yAxis2->setVisible(true);

    ui->customPlot->legend->setVisible(true);
    ui->customPlot->replot();
}

void Widget::updatePlotTick()
{
    // --- Actualizar TODAS las curvas de VELOCIDAD (mm/s) en eje izquierdo ---
    for (int k = 0; k < yVoltajes.size(); ++k) {
        // desplazar ventana
        for (int i = 0; i < yVoltajes[k].size() - 1; ++i)
            yVoltajes[k][i] = yVoltajes[k][i + 1];

        // valor nuevo (ejemplo: escala por serie; reemplaza por tu dato real si lo tienes)
        const double nuevo = targetVel * (0.5 + 0.25 * k);
        yVoltajes[k].last() = nuevo;

        // aplicar a la gráfica k
        ui->customPlot->graph(k)->setData(x, yVoltajes[k]);
    }

    // --- Actualizar la curva de RPM en el eje derecho (yAxis2) ---
    if (!rpmData.isEmpty()) {
        for (int i = 0; i < rpmData.size() - 1; ++i)
            rpmData[i] = rpmData[i + 1];

        rpmData.last() = targetRPM;

        // La curva de RPM es la última que agregaste en setupPlot()
        const int rpmIndex = ui->customPlot->graphCount() - 1;
        ui->customPlot->graph(rpmIndex)->setData(x, rpmData);
    }

    // Redibujar
    ui->customPlot->replot();
}
/*
void Widget::readSerial()
{
    QByteArray buffer = ttl->readAll();

    serialData.append(buffer);

    ui->textEdit->setText(serialData);

    if (buffer.contains("RPM: ")) {
        bool ok;
        QString temp = buffer;
        QList<QString> param = temp.split("RPM: ");
        param[1].remove("\n");
        float rpm = param[1].toFloat(&ok);
        targetRPM = rpm;
    }
}*/
void Widget::readSerial()
{
    QByteArray chunk = ttl->readAll();
    serialData.append(chunk);

    while (true) {
        int nl = serialData.indexOf('\n');
        if (nl < 0) break;

        QByteArray rawLine = serialData.left(nl);
        serialData.remove(0, nl + 1);
        rawLine = rawLine.trimmed();

        if (rawLine.isEmpty()) continue;

        QString line = QString::fromUtf8(rawLine);
        int colon = line.indexOf(':');
        if (colon < 0) continue;

        QString key = line.left(colon).trimmed();
        QString val = line.mid(colon + 1).trimmed();

        bool ok = false;

        if (key == "RPM") {
            targetRPM = val.toDouble(&ok);

        }
        else if (key == "DIR") {
            targetDir = val.at(0).toLatin1();
        }
        else if (key == "VEL") {
            targetVel = val.toDouble(&ok);
        }
        else if (key == "DS1") {
            targetDs1 = val.toDouble(&ok);
            ui->progressBar_1->setValue(targetDs1);
        }
        else if (key == "DS2") {
            targetDs2 = val.toDouble(&ok);
            ui->progressBar_2->setValue(targetDs2);
        }
        else if (key == "DS3") {
            targetDs3 = val.toDouble(&ok);
            ui->progressBar_3->setValue(targetDs3);
        }
        else if (key == "DS4") {
            targetDs4 = val.toDouble(&ok);
            ui->progressBar_4->setValue(targetDs4);
        }
    }
}

void Widget::on_pushButton_clicked(){
    QString texto = ui->lineEdit->text().trimmed();
    bool ok;
    int t = texto.toInt(&ok);

    if (ui->lineEdit->text().trimmed().isEmpty()) {
        ui->label->setVisible(true);
        ui->label->setText("Ingrese la velocidad gran hp.");
        ui->label->adjustSize();
    }
    else if (!ui->lineEdit->text().trimmed().isEmpty() && !ok) {
        ui->label->setVisible(true);
        ui->label->setText("De preferencia numeros imbecil.");
        ui->label->adjustSize();
    }
    else {
        ui->label->setVisible(true);
        bool ok = false;
        quint32 v = texto.toUInt(&ok);
        if (!ok || v > 65535u) {
            ui->label->setText("Velocidad inválida (0..65535).");
            ui->label->adjustSize();
            return;
        }
        else {
            ui->label->setText("Velocidad en mm/s esparada: "+QString::number(t));
            ui->label->adjustSize();
            enviarVEL(texto);
        }
    }
}

void Widget::on_pushButton_2_clicked(){
    enviarVEL("0");
}

void Widget::on_pushButton_3_clicked()
{
    if (!ttl->isOpen()) {
        const QString port = ui->comboBox->currentText().trimmed();
        if (port.isEmpty()) return;

        ttl->setPortName(port);
        ttl->setBaudRate(QSerialPort::Baud115200);
        ttl->setDataBits(QSerialPort::Data8);
        ttl->setParity(QSerialPort::NoParity);
        ttl->setStopBits(QSerialPort::OneStop);
        ttl->setFlowControl(QSerialPort::NoFlowControl);

        if (!ttl->open(QIODevice::ReadWrite)) {
            qWarning() << "No se pudo abrir" << port << ":" << ttl->errorString();
            return;
        }
        connect(ttl, &QSerialPort::readyRead, this, &Widget::readSerial, Qt::UniqueConnection);
        ui->pushButton_3->setText("Cerrar");
    } else {
        ttl->close();
        //ui->textEdit->clear();
        ui->pushButton_3->setText("Abrir");
    }
}

void Widget::on_pushButton_4_clicked()
{
    ui->comboBox->clear();
    const auto ports = QSerialPortInfo::availablePorts();
    for (const auto& info : ports)
        ui->comboBox->addItem(info.portName());
}

void Widget::on_pushButton_5_clicked()
{
    plotting = !plotting;
    if (plotting) {
        ui->pushButton_5->setText("STOP");
        plotTimer->start();
    } else {
        plotTimer->stop();
        ui->pushButton_5->setText("Graficar");
    }
}

void Widget::on_pushButton_6_clicked()
{
    QUrl url("https://www.youtube.com/watch?v=fMiq-utP6SY&list=RDSr2D5YwJKCk&index=3");
    QDesktopServices::openUrl(url);
}

void Widget::on_pushButton_7_clicked()
{
    ui->textEdit->clear();
}


void Widget::on_horizontalSlider_actionTriggered(int action)
{
    int val = ui->horizontalSlider->value();
    enviarVEL(QString::number(val));
}


void Widget::on_pushButton_8_clicked()
{

}




